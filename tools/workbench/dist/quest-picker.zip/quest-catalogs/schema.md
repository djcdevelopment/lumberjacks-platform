# Schema — a guild quest catalog

One JSON file describes one guild's quest inventory for one era. Sibling of the rank-ladder
recipe: the ladder says *what a rank requires*, the catalog says *what each quest actually is*.

Top level:
- `schema_version` — number. Currently `1`.
- `guild` — text. The guild's name, e.g. `"Slayers"`.
- `era` — number. Which era these quests are for.
- `source` — object, optional. Where this came from: `{ "kind", "detail", "retrieved" }`
  (e.g. the tracker sheet tab and the date it was pulled). Provenance, not behavior.
- `quests` — the list of quests.

Each entry in `quests`:
- `quest_id` — text. Stable slug, unique within the catalog, e.g. `"air_drop"`. Generated
  from the name; never changes once players reference it.
- `name` — text. The quest's name as the guild writes it, e.g. `"Air Drop"`. Verbatim —
  except a parenthesized annotation the sheet appends on its own line, which moves to:
- `name_note` — text or null, optional. Sheet annotation split off the name, verbatim,
  e.g. `"(new)"` or `"(Ranger Station)"`.
- `reward` — text or null, optional. Per-quest reward as written, e.g. `"1 Queen Bee"`.
  (Rank-level rewards live in the rank ladder, not here.)
- `category` — text. The guild's grouping, e.g. `"General summons"`, `"Rogue summons"`.
  Copied as written — the guild's taxonomy, not ours.
- `coopable` — true/false. Whether a group turn-in credits everyone mentioned.
- `requirements` — text. What you must do, copied **verbatim** including the evidence
  emoji (📸 screenshot, 🎞️ optional video, 🔗 Discord link, 🤜🤛 group turn-in). We
  standardize the plumbing, never the content.
- `evidence` — object, derived from the bot command's slots (the machine-readable truth):
  - `screenshots` — number. How many `image:` slots the turn-in command has (0–4).
  - `video_alternative` — true/false. 🎞️ appears in the requirements text.
  - `link` — true/false. Command has a `summons_url:` slot.
  - `group_turnin` — true/false. Command has a `participants:` slot.
  - `notes` — true/false. Command has a `summons_notes:` or `badge_notes:` slot.
- `evidence_note` — text or null, optional. The guild's free-text description of the
  required evidence (the Ranger tracker's "Required Screenshots" column), verbatim.
- `bot_command` — text. The **verbatim** turn-in command with empty slots, e.g.
  `"/slayer summons summons_type:Air Drop image: image2:"`. Null for auto-checked quests.
- `auto_checked` — true/false. True for meta-quests with no submission (the bot or a
  human checks them off automatically, e.g. "complete all 4 of the above").
- `venue` — text. `"in_game"` or `"irl"`. Defaults to `"in_game"`; exists now so
  Ranger-style real-life badge quests don't force a schema change later.
- `trigger` — object or null. A machine-readable spec for automatic in-game completion;
  null means manual completion only. `event` uses the stable creator vocabulary generated
  in `tools/component-packets/samples/quest-capability-manifest.json`. `target` is the
  optional subject substring; the existing `weapon_skill`, `projectile`, and `shots`
  fields remain accepted. `hit` is a schema-1 compatibility alias for both creature and
  resource damage. Additive `where` filters event-specific scalar fields without a schema
  bump, for example:

  ```json
  { "event": "station_input_added", "target": "CopperOre",
    "where": { "station": "smelter", "item": "CopperOre" } }
  ```

  The shared evaluator accepts all 34 creator-safe canonical events; in-game support is
  claimed only after a normalized producer, dedupe guard, and witness receipt land. See
  `quest-view-schema.md` for exact matching and rejection rules, and the generated
  capability manifest for each event's creator-facing target and filter fields.

That's the whole shape. If you need a field that isn't here, add it — then teach
`validate.py` and the harvest adapters about it.

## Where catalogs come from

Catalogs are **harvested, not hand-written**. `harvest.py` reads `sources.json` (the
configurator: which guild, which source, which adapter) and emits the catalog plus an
**anomalies report**. A source may declare a `kind` — `"quest-catalog"` (the default)
or `"rank-ladder"` — and the adapter emits that kind's artifact: ladder sources emit
the shape in `../rank-ladders/schema.md` (plus `achievements` / `village_achievements`
lists and an `entry_id` join key per entry) and are validated by that recipe's
validator, not this one. `render_quest_picker.py` only embeds quest-catalog sources. Anything odd in the source — duplicate bot commands, mismatched
evidence counts, unparseable rows — lands in the report for the guild to rule on. The
harvester never silently fixes the guild's content.

## The provenance sidecar

Each harvest also emits `<output>-provenance.json`: the leader-facing record of what
the adapter actually did. It **never flows into `quest-view.json` or the mod** — it
exists so `render_provenance.py` can show a leader their artifact's journey
(`data/processed/provenance-<source-id>.html`).

Shape (schema_version 1):
- `mode` — `"sheet"` or `"passthrough"` (gm-template has no cells to echo).
- `source` — the sources.json entry: id, guild, era, adapter, path, tab, url, retrieved.
- `tabs[]` — per tab read: `tab`, `header_row`, `columns[]`
  (`{index, letter, header, fields, note}` — which canonical fields each column became),
  and `rows[]`.
- `rows[]` — the fate of every row: `{row, outcome, quest_id?, reason?, cells?}`.
  `row` is always the **1-based spreadsheet row**, so a leader can open their own
  sheet and find it. `outcome` is one of `quest | skipped | blank | filler | header |
  banner | section` — plus, for rank-ladder sources, `rank | achievement | detail`
  (`detail` rows carry `entry`, the owning entry's id; `quest_id` doubles as the
  generic join key for ladder entries' `entry_id`). `cells` echoes only mapped
  columns, keyed by spreadsheet letter, verbatim, truncated at 500 chars
  (`truncated: true` when cut).
- `anomalies` — the structured anomaly list (below).
- `counts` — rows_seen / quests / entries / skipped / blank / anomalies. `quests`
  is the emitted-entry count for **every** kind (ladder entries included) so the
  invariant and validator stay one code path. `harvest.py` fails loudly if these
  disagree with the artifact.

Anomalies are structured objects — `{kind, row, tab, quest_id, quest_name, message}` —
with `kind` slugs like `skipped_row`, `duplicate_credit`, `credit_mismatch`,
`evidence_mismatch`, `header_mismatch`, `tbd_status`. The human-readable
`-anomalies.md` is formatted from this same list (`format_anomaly`), and the
provenance page joins each anomaly to the row or quest it concerns.
