# Anomalies — Sample Guild quest catalog (sample-guild)

The harvester copies the guild's content verbatim and flags what looks off.
Nothing here was 'fixed' — these are questions for the guild to rule on.

1. row 8 ('Retired: Boar Parade'): has a name but no other data — skipped.
2. 1 row(s) skipped for missing data (listed above).
3. **Troll Tussle**: bot command credits `Troll Scuffle` — not the quest's own name. Typo or intentional?
